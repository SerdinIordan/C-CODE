﻿using Microsoft.Security.Application;
using PublicShapefileService.Models;
using PublicShapefileService.Models.FieldsValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using CaptchaMvc.HtmlHelpers;

namespace PublicShapefileService.Controllers
{
    public class IndexController : Controller
    {
        //
        // GET: /Index/

        public ActionResult Index()
        {
            return View();
        }

        /*public ActionResult Menu()
        {
            return View("AdaugaSolicitant");
        }

        //[HttpPost]
        [ValidateInput(false)]
        public ActionResult AddSolicitant(ShapefileRequest op)
        {
            try
            {
                if (verificaManipulariJavaScriptXSS(op))
                {
                    ViewBag.MessageManipulariJavaScript = "Nu sunt permise manipulari JavaScript/XSS(taguri, scripturi html)";
                }

                if (ModelState.IsValid && !verificaManipulariJavaScriptXSS(op))
                {
                    
                    if (this.IsCaptchaValid("Captcha is not valid"))
                    {
                        TempData["data"] = "Solicitantul a fost adaugat cu succes!";
                        //Manager.StartFlux(op);
                        return RedirectToAction("Index");
                       
                    }
                    ViewBag.ErrMessageCaptcha = "Codul Captcha nu este valid.";
                    return View("AdaugaSolicitant");
                }
                else
                {
                    
                    return View("AdaugaSolicitant");
                }
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Index/Details/5

        public ActionResult Details(int id)
        {
            return View();
        }

        //
        // GET: /Index/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Index/Create

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Index/Edit/5

        public ActionResult Edit(int id)
        {
            return View();
        }

        //
        // POST: /Index/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Index/Delete/5

        public ActionResult Delete(int id)
        {
            return View();
        }

        //
        // POST: /Index/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }


        //vom face o metoda care verifica fiecare camp si vede daca avem manipulari javaScript(folosindu-ne de biblioteca XSS) 
        public bool verificaManipulariJavaScriptXSS(ShapefileRequest op)
        {
            //incercam sa luam campurile fara scripturi, taguri html
            //daca avem manipulari javascript atunci va returna true altfel false
            string numeSolicitant = Sanitizer.GetSafeHtmlFragment(op.SolicitantName);
            string cui = Sanitizer.GetSafeHtmlFragment(op.CUI);
            string zonaDeInteres = Sanitizer.GetSafeHtmlFragment(op.InterestArea);
            string emailSolicitant = Sanitizer.GetSafeHtmlFragment(op.SolicitantEmail);
            string detaliiCerere = Sanitizer.GetSafeHtmlFragment(op.RequestDetail);
            if ((!numeSolicitant.Equals(op.SolicitantName) && (op.SolicitantName != null)))
            {
                return true;
            }
            if (!cui.Equals(op.CUI) && (op.CUI != null))
            {
                return true;
            }
            if (!emailSolicitant.Equals(op.SolicitantEmail) && (op.SolicitantEmail != null))
            {
                return true;
            }
            if (!detaliiCerere.Equals(op.RequestDetail) && (op.RequestDetail != null))
            {
                return true;
            }
            if (!zonaDeInteres.Equals(op.InterestArea) && (op.InterestArea != null))
            {
                return true;
            }
            return false;
        }
        */
       

    


    }
}
