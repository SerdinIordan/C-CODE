﻿using AttributeRouting.Web.Http;
using PublicShapefileService.DataLayer;
using PublicShapefileService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PublicShapefileService.Controllers
{
    public class OperatorController : Controller
    {
        //
        // GET: /DetailsOperator/
           private PublicShapefileServiceContext publicShapefileServiceOperations =
              new PublicShapefileServiceContext();
        private int id;

        

        [HttpGet]
        public ActionResult Operator()
        {
            //va trebui sa avem o metoda get by id pentru a lua solicitantul
            // var publicShapefileService = publicShapeFileService.GetShapefileRequestById(id);
            ViewData["AcceptShapefileRequest"] = createObjectDetail();
            return View();
        }
       

        [HttpGet]
        [HttpRoute("Solicitant/{id}")]
        public ActionResult Solicitant(int id)
        {
            
          //  var shapeFileRequest=  publicShapefileServiceOperations.GetShapefileRequestById(id);
            ViewData["AcceptShapefileRequest"] = createObjectDetail();
            // ShapefileRequest shapeFileRequest = new ShapefileRequest();
            return View("Operator");
        }

        public ShapefileRequest createObjectDetail()
        {
            ShapefileRequest op = new ShapefileRequest();

            op.ShapefileRequestId = 1;
            op.CUI = "2030213";
            op.SolicitantName = "Serdin Iordan";
            op.InterestArea = "Pipera";
            op.SolicitantEmail = "iordan.serdin@gmail.com";
            op.RequestDetail = "Acestea sunt detaliile solicitantului";

            return op;
        }

        [HttpPost]
        public ActionResult AcceptRequest(OperatorResolution operatorResolution)
        {
            try
            {

                // var publicShapeFileRequest = GetShapefileRequestById(id);
                var operatorResolutionSave = new OperatorResolution();
                operatorResolutionSave.OperatorName = operatorResolution.OperatorName;
                operatorResolutionSave.ResolutionDetails = null;
                //se completeaza detalii daca se respinge cererea
                operatorResolutionSave.Timestamp = DateTime.Now;
                operatorResolutionSave.Resolution = true;

                //nu stiu ce trimit operatorResolutionSave sau ShapefileRequest
                //publicShapefileServiceOperations.SaveShapefileRequest(operatorResolutionSave);
                ViewData["AcceptShapefileRequest"] = createObjectDetail();
                ViewBag.MessageAcceptRequest = "Cererea a fost aprobata cu succes!";
                return View("Result", operatorResolutionSave);
                // return View();
            }
            catch
            {
                //TODO: Log error				
                return View();
            }

        }

        [HttpPost]
        public ActionResult RejectRequest(OperatorResolution operatorResolution)
        {
            try
            {

                // var publicShapeFileRequest = GetShapefileRequestById(id);
                var operatorResolutionSave = new OperatorResolution();
                operatorResolutionSave.OperatorName = operatorResolution.OperatorName;
                operatorResolutionSave.ResolutionDetails = operatorResolution.ResolutionDetails;
                //se completeaza detalii daca se respinge cererea
                operatorResolutionSave.Timestamp = DateTime.Now;
                operatorResolutionSave.Resolution = false;

                //nu stiu ce trimit operatorResolutionSave sau ShapefileRequest
                //publicShapefileServiceOperations.SaveShapefileRequest(operatorResolutionSave);
                ViewData["AcceptShapefileRequest"] = createObjectDetail();
                ViewBag.MessageRejectRequest = "Cererea a fost respinsa cu succes!";
                return View("Result", operatorResolutionSave);
                // return View();
            }
            catch
            {
                //TODO: Log error				
                return View();
            }

        }

    }
}
