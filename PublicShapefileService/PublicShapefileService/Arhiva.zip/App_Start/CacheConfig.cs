﻿using System;
using System.Collections.Generic;
using System.Runtime.Caching;
using System.IO;
using PublicShapefileService.Models;

namespace PublicShapefileService.App_Start
{
    public class CacheConfig
    {
        public static void DoCaching(String route)
        {
            MemoryCache memory = MemoryCache.Default;
            String[] directories = Directory.GetDirectories(route);
            CacheItemPolicy policy = new CacheItemPolicy();

            //Citire din baza de date
            //CacheFile[] localities = GetAllLocalities();

            //evitare eroare
            CacheFile[] localities = new CacheFile[2];
            String[] testLayers = new String[2];
            localities[0] = new CacheFile("asd", "qwe", "Popesti", testLayers);
            localities[1] = new CacheFile("java", "bla", "Olteni", testLayers);

            //populare layere
            foreach (var locality in localities)
            {
                String currentRoute = route + $@"{locality.CountyCode}" + $@"\{locality.SirutaCode}";
                String[] layersRoute = Directory.GetFiles(currentRoute);
                List<String> layers = new List<String>();
                foreach (var layerRoute in layersRoute)
                {
                    char[] delimiters = { '.', '\\' };
                    var fileName = layerRoute.Split(delimiters);
                    String layer = fileName[fileName.Length - 2];
                    layers.Add(layer);
                }
                locality.Layers = layers.ToArray();
            }
        }
    }
}