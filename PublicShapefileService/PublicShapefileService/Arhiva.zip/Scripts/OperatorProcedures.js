﻿

function AcceptRequest(ctl, event) {
    event.preventDefault();
    swal({
        title: "Doriti sa confirmati cererea?",
        text: "Please check Information before Submiting!",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Confirma",
        cancelButtonText: "Cancel",
        closeOnConfirm: false,
        closeOnCancel: false
    },
        function (isConfirm) {
            if (isConfirm) {
                // if (validateData() == true) {
                // $("#CreateForm").submit();
                $('form').attr('action', "http://localhost/PublicShapefileService/Operator/AcceptRequest").submit();
                //  $("form").submit();

            } else {
                swal("Cancelled", "You have Cancelled Form Submission!", "error");
            }
        });
}



function RejectRequest(ctl, event) {
    event.preventDefault();
    swal({
        title: "Doriti sa respingeti cererea?",
        text: "Please check Information before Submiting!",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Respinge",
        cancelButtonText: "Cancel",
        closeOnConfirm: false,
        closeOnCancel: false
    },
        function (isConfirm) {
            if (isConfirm) {
                // if (validateData() == true) {
                // $("#CreateForm").submit();
                $('form').attr('action', "http://localhost/PublicShapefileService/Operator/RejectRequest").submit();
                //  $("form").submit();

            } else {
                swal("Cancelled", "You have Cancelled Form Submission!", "error");
            }
        });
}






function ApprovesOperatorResolution() {
    swal({
        title: "Are you sure?",
        text: "Your will not be able to recover this imaginary file!",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Yes, delete it!",
        closeOnConfirm: false
    },
        function () {
            swal("Deleted!", "Your imaginary file has been deleted.", "success");
        });
} 




