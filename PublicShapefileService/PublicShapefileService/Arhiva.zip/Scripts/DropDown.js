﻿

$(function () {
    //$.widget("custom.catcomplete", $.ui.autocomplete, {
    //    _create: function () {
    //        this._super();
    //        this.widget().menu("option", "items", "> :not(.ui-autocomplete-category)");
    //    },
    //    _renderMenu: function (ul, items) {
    //        var that = this,
    //            currentCategory = "";
    //        $.each(items, function (index, item) {
    //            var li;
    //            if (item.CUI != currentCategory) {
    //                ul.append("<li class='ui-autocomplete-category'>" + item.CUI + "</li>");
    //                currentCategory = item.CUI;
    //            }
    //            li = that._renderItemData(ul, item);
    //            if (item.CUI) {
    //                li.attr("aria-label", item.CUI + " : " + item.InterestArea);
    //            }
    //        });
    //    }
    //});
    
    $("#DropDown").autocomplete({
        source: function (request, response) {
            var param = { keyword: $('#DropDown').val() };
            $.ajax({
                url: "http://localhost/PublicShapefileService/Download/Get",
                data: "{'keyword':' " + request.term + "'}",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    response($.map(data, function (item) {
                        return item;
                    }))
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert(textStatus);
                }
            });
        },
        minLength: 3,
        delay:0,
        select: function (event, ui) {
            var LastValue = splitCurrentText(this.value);
            LastValue.pop();
            LastValue.push(ui.item.value);
            LastValue.push("");
            this.value = LastValue.join(",");
            return false;  
        },
        focus: function () {
            return false;
        }
    });
    function splitCurrentText(LastTerm) {

        return LastTerm.split(/,\s*/);
    }

    function GetCurrentSearchTerm(LastTerm) {

        return splitCurrentText(LastTerm).pop();
    }  
});